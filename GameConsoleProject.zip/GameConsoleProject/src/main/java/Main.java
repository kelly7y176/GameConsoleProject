
public class Main {
    public static void main(String[] args) {
        GameConsole.main(args);   
    }
}
